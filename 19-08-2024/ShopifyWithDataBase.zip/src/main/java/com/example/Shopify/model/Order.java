package com.example.Shopify.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
@Table(name = "orders")
public class Order {

    @Id
    private int id;
    private String status;

    @ManyToOne
    private Customer customer;

    @OneToMany
    private List<OrderDetail> orderDetails;

}
