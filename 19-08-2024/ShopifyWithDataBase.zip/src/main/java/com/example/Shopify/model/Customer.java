package com.example.Shopify.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

import java.util.List;

@Entity
@Data
@Table(name = "customers")
public class Customer {

    @Id
    private int id;
    private String userName;
    private String lastName;
    private String firstName;

    @OneToMany
    private List<Order> orders;

    @OneToMany
    private List<Payment> payments;
}
