package com.example.Shopify.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "orderdetails")
public class OrderDetail {

    @Id
    private int id;
    @Column(name = "code")
    private String productCode;
    private int quantity;

    @ManyToOne
    private Order order;

    @ManyToOne
    private Product product;
}
