package com.example.banking_app.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

import java.util.UUID;

@Data
@ToString
@Entity
@Table(name = "cards")
public class Card {

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private UUID id;
    @Column(name="expiration_date")
    private String expirationDate;

    @ManyToOne
    @JoinColumn(name="account_id")
    private Account account;
}
