package com.example.banking_app.mapper;

import com.example.banking_app.dto.ClientDto;
import com.example.banking_app.model.Client;
import org.mapstruct.Mapper;


@Mapper(componentModel = "spring")
public interface ClientMapper {
    Client toClient(ClientDto clientDto);
    ClientDto toClientDto(Client client);
}
