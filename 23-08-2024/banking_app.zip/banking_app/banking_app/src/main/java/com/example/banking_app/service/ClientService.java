package com.example.banking_app.service;

import com.example.banking_app.dto.ClientDto;
import com.example.banking_app.mapper.ClientMapper;
import com.example.banking_app.model.Client;
import com.example.banking_app.repository.ClientRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class ClientService {

    private ClientMapper clientMapper;

    private ClientRepository clientRepository;

    public void saveClient(ClientDto clientDto) {
        Client client = clientMapper.toClient(clientDto);
        clientRepository.save(client);
    }
}
