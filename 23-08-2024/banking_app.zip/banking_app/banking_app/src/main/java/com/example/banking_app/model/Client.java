package com.example.banking_app.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;
import java.util.UUID;

@Data
@ToString
@Entity
@Table(name = "clients")
@AllArgsConstructor
@NoArgsConstructor
public class Client {

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private UUID id;
    private String name;
    private String password;
    private String cnp;

    @OneToMany(mappedBy = "id", cascade = CascadeType.ALL,orphanRemoval = true)
    private List<Account> accounts;

}
