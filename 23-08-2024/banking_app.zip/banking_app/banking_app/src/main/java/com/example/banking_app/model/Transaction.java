package com.example.banking_app.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

import java.util.List;
import java.util.UUID;

@Data
@ToString
@Entity
@Table(name = "transactions")
public class Transaction {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private UUID id;
    private enum type {
        ADD,
        WITHDRAW
    }
    private int amount;

    @ManyToOne
    @JoinColumn(name="account_id")
    private Card card;

}
