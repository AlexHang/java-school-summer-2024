package com.example.banking_app.controller;

import com.example.banking_app.model.Account;
import com.example.banking_app.service.AccountService;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@NoArgsConstructor
public class AccountController {

    private AccountService accountService;

    @PostMapping("/apenaccount/{id}")
    public void saveAccount(@PathVariable int id, @RequestBody Account account) {
        accountService.saveAccount(account);
    }


}
