package com.example.banking_app.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

import java.util.List;
import java.util.UUID;

@Data
@ToString
@Entity
@Table(name = "accounts")

public class Account {

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private UUID id;
    private int balance;
    private int limita;

    @ManyToOne
    @JoinColumn(name="client_id")
    private Client client;


    @OneToMany(mappedBy = "id", cascade = CascadeType.ALL,orphanRemoval = true)
    private List<Card> cards;
    private String type;

    @OneToMany(mappedBy = "id", cascade = CascadeType.ALL,orphanRemoval = true)
    private List<Transaction> transactions;



}
