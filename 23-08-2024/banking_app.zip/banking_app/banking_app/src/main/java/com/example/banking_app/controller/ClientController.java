package com.example.banking_app.controller;

import com.example.banking_app.dto.ClientDto;
import com.example.banking_app.model.Client;
import com.example.banking_app.service.ClientService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor

public class ClientController {

    private ClientService clientService;

    @PostMapping("/register")
    public void save(@RequestBody ClientDto clientDto) {
        clientService.saveClient(clientDto);

    }
}
