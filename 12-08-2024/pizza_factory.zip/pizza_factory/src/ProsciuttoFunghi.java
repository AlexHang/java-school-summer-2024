public class ProsciuttoFunghi extends Pizza {
    public ProsciuttoFunghi() {
        description = "Prosciutto Funghi";
    }

    @Override
    public double cost() {
        return 10.00;
    }
}