public class QuattroStagioni extends Pizza {
    public QuattroStagioni() {
        description = "Quattro Stagioni";
    }

    @Override
    public double cost() {
        return 12.00;
    }
}