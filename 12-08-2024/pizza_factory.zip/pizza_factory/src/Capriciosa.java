public class Capriciosa extends Pizza {
    public Capriciosa() {
        description = "Capriciosa";
    }

    @Override
    public double cost() {
        return 11.00;
    }
}