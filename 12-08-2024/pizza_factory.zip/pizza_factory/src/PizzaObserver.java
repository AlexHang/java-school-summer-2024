public interface PizzaObserver {
    public void update(Pizza pizza);
}
