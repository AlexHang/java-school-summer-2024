import java.util.Observable;
import java.util.Observer;

public class PizzaFactory implements PizzaObserver {
    private static PizzaFactory instance;
    Client client;
    private PizzaFactory(){
    }

    public static PizzaFactory getInstance() {
        if (instance == null) {
            instance = new PizzaFactory();
        }
        return instance;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Pizza createPizza(String type) {
        Pizza pizza;
        switch (type) {
            case "Marguerita":
                pizza = new Marguerita();
                break;
            case "Prosciutto Funghi":
                pizza = new ProsciuttoFunghi();
                break;
            case "Capriciosa":
                pizza = new Capriciosa();
                break;
            case "Quattro Stagioni":
                pizza = new QuattroStagioni();
                break;
            default:
                throw new IllegalArgumentException("Unknown pizza type");
        }
        //notify observer
        notifyObserver(pizza);
        return pizza;
    }
    @Override
    public void update(Pizza pizza) {
        System.out.println("pizza created factory " + pizza);
    }


    private void notifyObserver(Pizza pizza)
    {
        this.update(pizza);
        client.update(pizza);
    }

}
