public class Marguerita extends Pizza {
    public Marguerita() {
        description = "Marguerita";
    }

    @Override
    public double cost() {
        return 8.00;
    }

    @Override
    public String toString() {
        return "Marguerita{" +
                "description='" + description + '\'' +
                '}';
    }
}