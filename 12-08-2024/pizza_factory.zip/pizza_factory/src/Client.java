public class Client implements PizzaObserver{

    String name;

    public Client(String name) {
        this.name = name;
    }

    @Override
    public void update(Pizza pizza) {
        System.out.println("pizza created client " + pizza);
    }
}
