public class Main {
    public static void main(String[] args) {
        Client client = new Client("marius");
        PizzaFactory pizzaFactory = PizzaFactory.getInstance();
        pizzaFactory.setClient(client);
        pizzaFactory.createPizza("Marguerita");
    }
}